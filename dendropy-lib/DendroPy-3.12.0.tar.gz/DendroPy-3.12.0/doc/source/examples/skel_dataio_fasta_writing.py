d.write_to_path(
        'data.fas',
        'fasta',
        taxon_set=None,
        wrap=False,
        wrap_width=70)

