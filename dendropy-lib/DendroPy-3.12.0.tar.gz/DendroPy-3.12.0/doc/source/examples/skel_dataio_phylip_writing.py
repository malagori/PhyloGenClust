d.write_to_path(
        'data.day',
        'phylip',
        taxon_set=None,
        strict=False,
        space_to_underscores=False,
        force_unique_taxon_labels=False)



