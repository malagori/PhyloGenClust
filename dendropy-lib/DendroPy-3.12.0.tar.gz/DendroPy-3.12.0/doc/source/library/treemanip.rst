***********************************************
:mod:`dendropy.treemanip` -- Tree Manipulation
***********************************************

.. module:: treemanip

.. toctree::
    :maxdepth: 2

.. automodule:: dendropy.treemanip
    :members:
