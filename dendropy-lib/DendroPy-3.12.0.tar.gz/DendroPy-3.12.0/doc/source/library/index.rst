##########################
DendroPy Library Reference
##########################

.. toctree::
    :maxdepth: 2

    base.rst
    taxon.rst
    tree.rst
    dataset.rst
    char.rst
    coalescent.rst
    reconcile.rst
    treecalc.rst
    treemanip.rst
    treesim.rst
    continuous.rst
    genbank.rst
