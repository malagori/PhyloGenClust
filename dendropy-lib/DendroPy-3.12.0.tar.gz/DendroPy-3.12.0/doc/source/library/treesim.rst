******************************************
:mod:`dendropy.treesim` -- Tree Simulation
******************************************

.. module:: treesim

.. toctree::
    :maxdepth: 2

.. automodule:: dendropy.treesim
    :members:
