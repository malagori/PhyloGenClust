**********************************************************
:mod:`dendropy.dataobject.dataset` -- Primary Data Manager
**********************************************************

.. module:: dataset

.. toctree::
    :maxdepth: 2

.. autoclass:: dendropy.dataobject.dataset.DataSet
    :members:
