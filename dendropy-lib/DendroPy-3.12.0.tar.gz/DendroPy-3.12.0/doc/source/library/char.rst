*************************************************
:mod:`dendropy.dataobject.char` -- Character Data
*************************************************

.. module:: char

.. toctree::
    :maxdepth: 2

.. automodule:: dendropy.dataobject.char
    :members:
