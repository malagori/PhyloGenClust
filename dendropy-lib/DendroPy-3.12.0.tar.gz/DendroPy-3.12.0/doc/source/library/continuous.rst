**************************************************************************
:mod:`dendropy.continuous` -- Continuous Character Simulation and Analysis
**************************************************************************

.. module:: continuous

.. toctree::
    :maxdepth: 2

.. automodule:: dendropy.continuous
    :members:
