***********************************
What's New in the DendroPy Tutorial
***********************************

2011-05-26
==========

    * Major update to the :doc:`tree manipulation section </tutorial/treemanips>` section.


2010-08-09
==========

    * Added documentation for new :doc:`NCBI </tutorial/ncbi>` interoperability module.

2010-03-17
==========

    * New content added to the :doc:`tree simulation section </tutorial/treesims>`.
    * New content (minor) added to the :doc:`tree manipulation section </tutorial/treemanips>`.
    * Changed the documentation theme.

2010-01-15
==========

    * Reorganized some of the content. New content coming soon ...
